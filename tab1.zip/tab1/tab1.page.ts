import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  IonButton,
  IonButtons,
  IonContent,
  IonHeader,
  IonItem,
  IonLabel,
  IonList,
  IonSearchbar,
  IonSpinner,
  IonText,
  IonTitle,
  IonToolbar,
} from '@ionic/angular/standalone';
import { InventoryService } from '../services/inventory.service';
import { Item } from '../models/item.model';
import { HelpButtonComponent } from '../shared/help-button/help-button.component';
import { firstValueFrom } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HelpButtonComponent,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonContent,
    IonSearchbar,
    IonButton,
    IonList,
    IonItem,
    IonLabel,
    IonText,
    IonSpinner,
  ],
})
export class Tab1Page {
  items: Item[] = [];
  searchName = '';
  loading = false;
  errorMessage = '';

  constructor(
    private inventory: InventoryService,
    private route: ActivatedRoute,
    private router: Router,
  ) {}

  ionViewWillEnter(): void {
    const q = this.route.snapshot.queryParamMap.get('search')?.trim() ?? '';
    if (q) {
      this.searchName = q;
      void this.search();
      return;
    }
    void this.loadAll();
  }

  async loadAll(): Promise<void> {
    this.loading = true;
    this.errorMessage = '';
    try {
      this.items = await firstValueFrom(this.inventory.getAllItems());
    } catch (e) {
      this.errorMessage = 'Failed to load items. Please check your connection and try again.';
    } finally {
      this.loading = false;
    }
  }

  async search(): Promise<void> {
    const name = this.searchName.trim();
    if (!name) {
      await this.loadAll();
      return;
    }

    this.loading = true;
    this.errorMessage = '';
    try {
      const item = await firstValueFrom(this.inventory.getItemByName(name));
      this.items = item ? [item] : [];
      if (!item) this.errorMessage = `No item found for name "${name}".`;
    } catch (e) {
      this.errorMessage = 'Search failed. Please try again.';
    } finally {
      this.loading = false;
    }
  }

  openForEdit(itemName: string): void {
    const name = itemName.trim();
    if (!name) {
      return;
    }
    void this.router.navigate(['/tabs/tab3'], {
      queryParams: { item: name },
    });
  }
}
