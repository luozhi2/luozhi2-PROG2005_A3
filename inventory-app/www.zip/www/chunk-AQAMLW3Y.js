var o=["Electronics","Furniture","Clothing","Tools","Miscellaneous"],t=["In Stock","Low Stock","Out of Stock"];export{o as a,t as b};
