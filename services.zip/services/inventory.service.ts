import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { ApiListResponse, Item, NewItem } from '../models/item.model';

@Injectable({
  providedIn: 'root'
})
export class InventoryService {
  private readonly baseUrl = 'https://prog2005.it.scu.edu.au/ArtGalley';

  constructor(private http: HttpClient) { }

  getAllItems(): Observable<Item[]> {
    return this.http
      .get<ApiListResponse<Item> | Item[]>(this.baseUrl)
      .pipe(map((r) => this.toItems(r).filter((item) => Boolean(item.item_name?.trim()))));
  }

  getItemByName(name: string): Observable<Item | null> {
    return this.http
      .get<ApiListResponse<Item> | Item[]>(`${this.baseUrl}/${encodeURIComponent(name)}`)
      .pipe(map((r) => this.toItems(r)[0] ?? null));
  }

  addItem(item: NewItem): Observable<unknown> {
    return this.http.post(this.baseUrl, item);
  }

  updateItem(name: string, item: NewItem): Observable<unknown> {
    return this.http.put(`${this.baseUrl}/${encodeURIComponent(name)}`, item);
  }

  deleteItem(name: string): Observable<unknown> {
    return this.http.delete(`${this.baseUrl}/${encodeURIComponent(name)}`);
  }

  private toItems(response: ApiListResponse<Item> | Item[]): Item[] {
    if (Array.isArray(response)) {
      return response;
    }
    return response?.value ?? [];
  }
}