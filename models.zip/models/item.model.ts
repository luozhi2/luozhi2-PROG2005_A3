export type Category =
  | 'Electronics'
  | 'Furniture'
  | 'Clothing'
  | 'Tools'
  | 'Miscellaneous';

export type StockStatus = 'In stock' | 'Low stock' | 'Out of stock';

export interface Item {
  item_id: number;
  item_name: string;
  category: Category;
  quantity: number;
  price: number;
  supplier_name: string;
  stock_status: StockStatus;
  featured_item: number; // 0 or 1 (server uses integer)
  special_note?: string | null;
}

export type NewItem = Omit<Item, 'item_id'>;

export interface ApiListResponse<T> {
  value: T[];
  Count: number;
}

export const CATEGORIES: readonly Category[] = [
  'Electronics',
  'Furniture',
  'Clothing',
  'Tools',
  'Miscellaneous',
] as const;

export const STOCK_STATUSES: readonly StockStatus[] = [
  'In stock',
  'Low stock',
  'Out of stock',
] as const;

